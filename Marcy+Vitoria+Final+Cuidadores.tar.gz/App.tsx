import { useEffect, useState, useRef } from 'react';

import heroPalestra from "container:///mnt/data/src/assets/b08b269cbed95868-image_20260927_195703.jpg";
import fotoIdosos from "container:///mnt/data/src/assets/28c699d5c5ac6342-image_20260927_195707.jpg";
import fotoSobre from "container:///mnt/data/src/assets/e944e692a03fc34f-image_20260927_195821.jpg";
import fotoGrupo from "container:///mnt/data/src/assets/fa4d41ea2102d1e6-image_20260927_195826.jpg";
import fotoMulherChorando from "container:///mnt/data/src/assets/e9a02fa398e711d3-image_20260927_200036.jpg";
import fotoRodaMulheres from "container:///mnt/data/src/assets/e11159c04cc365b2-image_20260927_200048.jpg";

const WHATS_BASE = "https://wa.me/5527995799138";
const waLink = (text: string) => `${WHATS_BASE}?text=${encodeURIComponent(text)}`;
const CUIDADORES_EXACT_URL = "https://wa.me/5527995799138?text=Olá%20Marcy,%20vi%20no%20site%20sobre%20indicação%20de%20cuidadores%20referenciados%20em%20Vitória%20e%20gostaria%20de%20saber%20mais";

const TEXTOS_WA = {
  geral: "Olá Marcy, vi seu site e sou de Vitória, gostaria de agendar",
  recomeço: "Olá Marcy, vi sobre o Programa Recomeço em Vitória e quero saber mais",
  cuidadores: "Olá Marcy, vi no site sobre indicação de cuidadores referenciados em Vitória e gostaria de saber mais",
  palestra: "Olá Marcy, gostaria de contratar uma palestra em Vitória / Grande Vitória",
  idoso: "Olá Marcy, me interessei pelo Recomeço Terceira Idade em Vitória",
  mulheres: "Olá Marcy, me interessei pelo Recomeço Mulheres em Reconstrução em Vitória",
};

function useFadeIn() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) e.target.classList.add("in");
        });
      },
      { threshold: 0.12 }
    );
    el.querySelectorAll(".fade-up").forEach((n) => io.observe(n));
    return () => io.disconnect();
  }, []);
  return ref;
}

export default function App() {
  const [mobileMenu, setMobileMenu] = useState(false);
  const [recomecoOpen, setRecomecoOpen] = useState(false);
  const [formStatus, setFormStatus] = useState<null | string>(null);
  const [busy, setBusy] = useState(false);
  const [formData, setFormData] = useState({
    nome: "",
    whatsapp: "",
    bairro: "",
    tipo: "Cuidadores Referenciados - Vitória",
    mensagem: "",
  });
  const [recordsCount, setRecordsCount] = useState<number | null>(null);

  const mainRef = useFadeIn();

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetch("actions", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ action: "records.list", args: { collection: "solicitacoes_vitoria" } }),
        });
        if (!res.ok) return;
        const j = await res.json();
        if (j.data) setRecordsCount(j.data.records.length);
      } catch {}
    };
    load();
  }, []);

  const submitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nome || !formData.whatsapp) {
      setFormStatus("Preencha nome e WhatsApp");
      return;
    }
    setBusy(true);
    setFormStatus(null);
    try {
      const value = { ...formData, origem: "Site Vitória ES", createdAt: new Date().toISOString() };
      const res = await fetch("actions", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          action: "records.create",
          args: { collection: "solicitacoes_vitoria", value, idempotency_key: `${formData.nome}-${formData.whatsapp}-${Date.now()}` },
        }),
      });
      const j = await res.json();
      if (!res.ok || j.error) throw new Error(j.error || "Erro ao salvar");
      setFormStatus("Recebido com carinho! Em breve entro em contato por WhatsApp. Você também pode me chamar direto no botão abaixo.");
      setRecordsCount((c) => (c ?? 0) + 1);
      setFormData({ nome: "", whatsapp: "", bairro: "", tipo: formData.tipo, mensagem: "" });
      try {
        const reloadRes = await fetch("actions", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ action: "records.list", args: { collection: "solicitacoes_vitoria" } }),
        });
        const rj = await reloadRes.json();
        if (rj.data) setRecordsCount(rj.data.records.length);
      } catch {}
    } catch (err: any) {
      setFormStatus(err.message || "Erro ao enviar. Tente pelo WhatsApp direto.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div data-safe-area-inset-root style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)", minHeight: "100vh" }} className="bg-[var(--surface)] overflow-x-clip">
      <header data-safe-area-sticky-top style={{ top: "var(--safe-area-inset-top)" }} className="sticky z-50 backdrop-blur-xl bg-[rgba(255,251,247,0.84)] border-b border-[var(--border)]">
        <div className="mx-auto max-w-[1280px] px-6 lg:px-8 h-[72px] lg:h-[84px] flex items-center justify-between">
          <a href="#inicio" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#D4AF7A] to-[#C17C74] flex items-center justify-center shadow-sm">
              <svg width="28" height="28" viewBox="0 0 32 32" fill="none">
                <path d="M16 24C16 24 7 18.5 7 13.5C7 10.5 9.2 8.5 12 8.5C14 8.5 16 10 16 10C16 10 18 8.5 20 8.5C22.8 8.5 25 10.5 25 13.5C25 18.5 16 24 16 24Z" fill="white" fillOpacity="0.95"/>
                <path d="M16 10C14.5 7.5 12 5.5 9.5 6.5C7 7.5 8 11 10.5 12M16 10C17.5 7.5 20 5.5 22.5 6.5C25 7.5 24 11 21.5 12" stroke="white" strokeWidth="1.2" strokeLinecap="round"/>
              </svg>
            </div>
            <div className="leading-none">
              <div className="font-display font-bold text-[19px] tracking-[-0.02em] text-[var(--vinho)]">Marcy Schettino</div>
              <div className="text-[10px] tracking-[0.18em] uppercase text-[var(--rosa-queimado)] font-semibold mt-[1px]">Vitória • ES | Recomeço</div>
            </div>
          </a>

          <nav className="hidden lg:flex items-center gap-7">
            <a href="#inicio" className="text-[13.5px] font-medium text-[var(--text-primary)] hover:text-[var(--vinho)] transition">Início</a>
            <a href="#sobre" className="text-[13.5px] font-medium text-[var(--text-primary)] hover:text-[var(--vinho)] transition">Sobre</a>
            <div className="relative">
              <button onClick={() => setRecomecoOpen((v) => !v)} className="text-[13.5px] font-medium flex items-center gap-1 text-[var(--text-primary)]">
                Recomeço <span className={`text-[10px] transition-transform inline-block ${recomecoOpen ? "rotate-180" : ""}`}>▼</span>
              </button>
              <div className={`absolute top-full left-1/2 -translate-x-1/2 mt-3 w-[220px] bg-white rounded-2xl shadow-[var(--shadow-medium)] border border-[var(--border)] p-2 transition-all ${recomecoOpen ? "opacity-100 visible" : "opacity-0 invisible pointer-events-none"}`}>
                <a href="#recomeco-idosos" onClick={() => setRecomecoOpen(false)} className="block px-4 py-2.5 rounded-xl text-[13px] hover:bg-[var(--nude)]">Terceira Idade</a>
                <a href="#recomeco-mulheres" onClick={() => setRecomecoOpen(false)} className="block px-4 py-2.5 rounded-xl text-[13px] hover:bg-[var(--nude)]">Mulheres</a>
              </div>
            </div>
            <a href="#cuidadores" className="text-[13.5px] font-medium flex items-center gap-2 text-[var(--text-primary)] hover:text-[var(--vinho)]">
              Cuidadores Referenciados
              <span className="px-2 py-[2px] rounded-full bg-[#6B7A5F] text-white text-[10px] font-bold tracking-wide">NOVO</span>
            </a>
            <a href="#palestras" className="text-[13.5px] font-medium text-[var(--text-primary)] hover:text-[var(--vinho)] transition">Palestras</a>
            <a href="#contato" className="text-[13.5px] font-medium text-[var(--text-primary)] hover:text-[var(--vinho)] transition">Contato</a>
          </nav>

          <div className="flex items-center gap-3">
            <a href={waLink(TEXTOS_WA.geral)} target="_blank" rel="noopener" className="hidden lg:inline-flex h-[40px] px-5 rounded-full bg-[#25D366] text-white text-[13px] font-bold items-center gap-2 shadow-[0_4px_16px_rgba(37,211,102,0.28)] hover:scale-[1.02] transition">
              <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
              AGENDAR VITÓRIA
            </a>
            <button onClick={() => setMobileMenu((v) => !v)} className="lg:hidden w-10 h-10 rounded-full border border-[var(--border)] flex items-center justify-center">
              <div className="space-y-1"><div className="w-4 h-[1.5px] bg-[var(--vinho)]" /><div className="w-4 h-[1.5px] bg-[var(--vinho)]" /><div className="w-4 h-[1.5px] bg-[var(--vinho)]" /></div>
            </button>
          </div>
        </div>

        {mobileMenu && (
          <div className="lg:hidden border-t border-[var(--border)] bg-[var(--creme)] px-6 py-6 space-y-4">
            <a href="#inicio" onClick={() => setMobileMenu(false)} className="block text-[15px] font-medium">Início</a>
            <a href="#sobre" onClick={() => setMobileMenu(false)} className="block text-[15px] font-medium">Sobre</a>
            <a href="#recomeco-idosos" onClick={() => setMobileMenu(false)} className="block text-[15px] font-medium">Recomeço - Terceira Idade</a>
            <a href="#recomeco-mulheres" onClick={() => setMobileMenu(false)} className="block text-[15px] font-medium">Recomeço - Mulheres</a>
            <a href="#cuidadores" onClick={() => setMobileMenu(false)} className="block text-[15px] font-medium flex items-center gap-2">Cuidadores Referenciados <span className="px-2 py-[2px] rounded-full bg-[#6B7A5F] text-white text-[10px]">NOVO</span></a>
            <a href="#palestras" onClick={() => setMobileMenu(false)} className="block text-[15px] font-medium">Palestras</a>
            <a href="#contato" onClick={() => setMobileMenu(false)} className="block text-[15px] font-medium">Contato</a>
            <a href={waLink(TEXTOS_WA.geral)} target="_blank" rel="noopener" className="flex h-12 rounded-full bg-[#25D366] text-white font-bold items-center justify-center gap-2 mt-2">AGENDAR VITÓRIA</a>
          </div>
        )}
      </header>

      <main ref={mainRef} className="mx-auto max-w-[1280px] px-6 lg:px-8">
        {/* HERO */}
        <section id="inicio" className="relative pt-10 lg:pt-16 pb-10 lg:pb-16">
          <div className="grid lg:grid-cols-[1.1fr_0.9fr] gap-8 lg:gap-10 items-center">
            <div className="relative">
              <div className="fade-up flex flex-wrap gap-2 mb-5">
                <span className="px-3 py-1 rounded-full bg-[var(--nude)] border border-[var(--border)] text-[11px] font-semibold tracking-wide text-[var(--vinho)]">VITÓRIA / ES • PRESENCIAL</span>
                <span className="px-3 py-1 rounded-full bg-white border border-[var(--border)] text-[11px] font-semibold tracking-wide text-[var(--text-secondary)]">ONLINE BRASIL</span>
                <span className="px-3 py-1 rounded-full bg-[#6B7A5F] text-white text-[11px] font-semibold tracking-wide">NOVO: CUIDADORES REFERENCIADOS</span>
              </div>

              <h1 className="fade-up font-display text-[40px] lg:text-[64px] leading-[0.95] tracking-[-0.03em] text-[var(--vinho)] text-balance">
                Cuidar da mente é também <span className="italic font-medium text-[var(--rosa-queimado)]">reconstruir caminhos.</span>
              </h1>

              <p className="fade-up mt-5 text-[14px] lg:text-[15px] leading-relaxed text-[var(--text-secondary)] max-w-[560px]">
                <strong className="text-[var(--text-primary)]">Bacharela em Serviço Social</strong> | Assistente Social (CRSS: 09100) | Psicanalista | Pós Graduada em Psicanálise | Palestrante em Vitória - ES. Criadora do Programa Recomeço para idosos e mulheres em reconstrução, agora com indicação de cuidadores referenciados em Vitória.
              </p>

              <div className="fade-up mt-6 flex flex-wrap gap-3">
                <div className="flex items-center gap-2 px-3 py-2 rounded-full bg-white border border-[var(--border)] shadow-sm">
                  <div className="w-6 h-6 rounded-full bg-[var(--nude)] flex items-center justify-center text-[12px]">👵</div>
                  <span className="text-[12px] font-medium">Terceira Idade - Lúdico Social</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-2 rounded-full bg-white border border-[var(--border)] shadow-sm">
                  <div className="w-6 h-6 rounded-full bg-[var(--nude)] flex items-center justify-center text-[12px]">🌸</div>
                  <span className="text-[12px] font-medium">Mulheres em Reconstrução</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-2 rounded-full bg-[#6B7A5F] text-white shadow-sm">
                  <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-[12px]">🤝</div>
                  <span className="text-[12px] font-semibold">Cuidadores Referenciados</span>
                </div>
              </div>

              <div className="fade-up mt-8 flex flex-col sm:flex-row gap-3">
                <a href={waLink(TEXTOS_WA.geral)} target="_blank" rel="noopener" className="h-[52px] px-7 rounded-full bg-[var(--vinho)] text-white font-semibold text-[14px] inline-flex items-center justify-center gap-2 hover:bg-[#5E2E3E] transition shadow-[var(--shadow-soft)]">
                  Agendar em Vitória <span>→</span>
                </a>
                <a href="#recomeco-idosos" className="h-[52px] px-7 rounded-full bg-white border border-[var(--border)] text-[14px] font-semibold inline-flex items-center justify-center gap-2 hover:bg-[var(--nude)] transition">
                  Conhecer Programa Recomeço
                </a>
              </div>

              <div className="fade-up mt-8 grid grid-cols-3 gap-4 max-w-[420px] border-t border-[var(--border)] pt-6">
                <div><div className="font-display text-[28px] font-semibold text-[var(--vinho)]">+8</div><div className="text-[11px] leading-tight text-[var(--text-muted)] uppercase tracking-wide">Anos de atuação no cuidado humano</div></div>
                <div><div className="font-display text-[28px] font-semibold text-[var(--vinho)]">Vitória</div><div className="text-[11px] leading-tight text-[var(--text-muted)] uppercase tracking-wide">Grande Vitória presencial</div></div>
                <div><div className="font-display text-[28px] font-semibold text-[var(--verde-folha)]">Novo</div><div className="text-[11px] leading-tight text-[var(--text-muted)] uppercase tracking-wide">Cuidadores com supervisão</div></div>
              </div>
            </div>

            <div className="fade-up relative">
              <div className="relative rounded-[32px] overflow-hidden bg-[var(--nude)] aspect-[4/5] shadow-[var(--shadow-medium)]">
                <img src={heroPalestra} alt="Marcy Schettino palestrando em Vitória ES - hero" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-[rgba(122,59,78,0.32)] via-transparent to-[rgba(255,251,247,0.2)]" />
                <div className="absolute bottom-4 left-4 right-4 flex gap-2">
                  <div className="px-3 py-2 rounded-2xl bg-white/90 backdrop-blur text-[11px] font-semibold text-[var(--vinho)] shadow-sm">📍 Vitória - ES • Auditório</div>
                  <div className="px-3 py-2 rounded-2xl bg-[var(--vinho)] text-white text-[11px] font-semibold shadow-sm">Palestras</div>
                </div>
              </div>
              <div className="absolute -top-4 -right-2 lg:-right-6 bg-white rounded-[20px] border border-[var(--border)] shadow-[var(--shadow-soft)] p-3 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#D4AF7A] to-[#C17C74] flex items-center justify-center text-white font-bold text-[12px]">MS</div>
                <div>
                  <div className="text-[12px] font-bold text-[var(--vinho)]">Marcy Schettino</div>
                  <div className="text-[10px] text-[var(--text-muted)]">CRSS 09100 • Vitória ES</div>
                </div>
                <div className="w-2 h-2 rounded-full bg-[#25D366] animate-pulse" />
              </div>
            </div>
          </div>
        </section>

        {/* 3 CAMINHOS */}
        <section id="caminhos" className="py-10 lg:py-16">
          <div className="fade-up flex flex-col lg:flex-row lg:items-end justify-between gap-4 mb-8">
            <div>
              <div className="text-[11px] tracking-[0.2em] uppercase font-bold text-[var(--rosa-queimado)] mb-2">Programa Recomeço em Vitória</div>
              <h2 className="font-display text-[34px] lg:text-[44px] leading-[0.95] tracking-[-0.02em] text-[var(--vinho)]">O Recomeço em Vitória -<br/>3 caminhos de cuidado</h2>
            </div>
            <p className="text-[13.5px] leading-relaxed text-[var(--text-secondary)] max-w-[380px]">Atendimento humanizado, lúdico e social. Presencial em Vitória, Vila Velha, Serra e Grande Vitória, e online para todo o Brasil.</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-5 lg:gap-6">
            <div className="fade-up rounded-[28px] bg-white border border-[var(--border)] overflow-hidden shadow-[var(--shadow-soft)] group hover:shadow-[var(--shadow-medium)] transition">
              <div className="h-[220px] overflow-hidden relative">
                <img src={fotoIdosos} alt="Recomeço Terceira Idade - atividade lúdica com idosos em Vitória" className="w-full h-full object-cover group-hover:scale-[1.03] transition duration-700" />
                <span className="absolute top-3 left-3 px-3 py-1 rounded-full bg-white/90 backdrop-blur text-[11px] font-bold text-[var(--vinho)]">VITÓRIA • PRESENCIAL</span>
              </div>
              <div className="p-6">
                <div className="flex items-center gap-2 mb-3"><div className="w-8 h-8 rounded-full bg-[var(--nude)] flex items-center justify-center">🧩</div><span className="text-[11px] font-bold tracking-wide uppercase text-[var(--rosa-queimado)]">Eixo 1</span></div>
                <h3 className="font-display text-[22px] font-semibold text-[var(--vinho)] leading-tight">Recomeço Terceira Idade</h3>
                <p className="mt-2 text-[13.5px] leading-relaxed text-[var(--text-secondary)]">Atividades lúdicas, vínculo e momentos com significado. Música, memórias, jogos, arte e conversas que resgatam autonomia em Vitória - ES.</p>
                <a href="#recomeco-idosos" className="mt-4 inline-flex text-[13px] font-semibold text-[var(--vinho)] hover:gap-2 gap-1 transition-all">Conhecer →</a>
              </div>
            </div>

            <div className="fade-up rounded-[28px] bg-[var(--vinho)] text-white overflow-hidden shadow-[var(--shadow-soft)] group hover:shadow-[var(--shadow-medium)] transition">
              <div className="h-[220px] overflow-hidden relative">
                <img src={fotoMulherChorando} alt="Recomeço Mulheres em Reconstrução - acolhimento em Vitória" className="w-full h-full object-cover opacity-90 group-hover:scale-[1.03] transition duration-700" />
                <span className="absolute top-3 left-3 px-3 py-1 rounded-full bg-white text-[11px] font-bold text-[var(--vinho)]">ACOLHIMENTO</span>
              </div>
              <div className="p-6">
                <div className="flex items-center gap-2 mb-3"><div className="w-8 h-8 rounded-full bg-white/15 flex items-center justify-center">🌷</div><span className="text-[11px] font-bold tracking-wide uppercase text-[#E9C2BB]">Eixo 2</span></div>
                <h3 className="font-display text-[22px] font-semibold leading-tight">Recomeço Mulheres em Reconstrução</h3>
                <p className="mt-2 text-[13.5px] leading-relaxed text-[#E9C2BB]">Acolhimento após relações tóxicas. Sem diagnosticar parceiros, complementar - não substitui terapia. Reconstrução com dignidade em Vitória.</p>
                <a href="#recomeco-mulheres" className="mt-4 inline-flex text-[13px] font-semibold text-white hover:gap-2 gap-1 transition-all">Conhecer →</a>
              </div>
            </div>

            <div className="fade-up rounded-[28px] bg-[#6B7A5F] text-white overflow-hidden shadow-[var(--shadow-soft)] relative group hover:shadow-[var(--shadow-medium)] transition">
              <div className="absolute top-0 right-0 w-24 h-24 bg-[#D4AF7A] rounded-bl-[32px] flex items-center justify-center"><span className="rotate-[15deg] text-[10px] font-black tracking-widest text-[#2D1F24]">NOVO<br/>VITÓRIA</span></div>
              <div className="h-[220px] overflow-hidden relative">
                <img src={fotoGrupo} alt="Cuidadores Referenciados - grupo de idosos em Vitória" className="w-full h-full object-cover group-hover:scale-[1.03] transition duration-700" />
                <span className="absolute bottom-3 left-3 px-3 py-1 rounded-full bg-[#D4AF7A] text-[11px] font-bold text-[#2D1F24]">REFERÊNCIAS VERIFICADAS</span>
              </div>
              <div className="p-6">
                <div className="flex items-center gap-2 mb-3"><div className="w-8 h-8 rounded-full bg-white/15 flex items-center justify-center">🤝</div><span className="text-[11px] font-bold tracking-wide uppercase text-[#D4E2CC]">Eixo 3 • NOVO EM VITÓRIA</span></div>
                <h3 className="font-display text-[22px] font-semibold leading-tight">Cuidadores Referenciados</h3>
                <p className="mt-2 text-[13.5px] leading-relaxed text-[#D4E2CC]">Indicação de cuidadores selecionados, capacitados e treinados para contratação em Vitória. Referências verificadas + Método Recomeço.</p>
                <a href="#cuidadores" className="mt-4 inline-flex text-[13px] font-semibold text-white hover:gap-2 gap-1 transition-all">Quero indicação em Vitória →</a>
              </div>
            </div>
          </div>
        </section>

        {/* CUIDADORES */}
        <section id="cuidadores" className="py-12 lg:py-20">
          <div className="rounded-[32px] bg-white border border-[var(--border)] shadow-[var(--shadow-soft)] overflow-hidden">
            <div className="grid lg:grid-cols-[1.35fr_0.85fr] gap-0">
              <div className="p-7 lg:p-12">
                <div className="fade-up flex flex-wrap items-center gap-3 mb-4">
                  <span className="px-3 py-1 rounded-full bg-[#6B7A5F] text-white text-[11px] font-bold tracking-wide">NOVO SERVIÇO EM VITÓRIA</span>
                  <span className="px-3 py-1 rounded-full bg-[var(--nude)] border border-[var(--border)] text-[11px] font-bold text-[var(--vinho)]">VITÓRIA • GRANDE VITÓRIA • ES</span>
                </div>
                <h2 className="fade-up font-display text-[30px] lg:text-[42px] leading-[0.95] tracking-[-0.02em] text-[var(--vinho)]">Cuidadores Referenciados,<br/>Selecionados e Capacitados<br/><span className="text-[var(--verde-folha)]">em Vitória - ES</span></h2>
                <p className="fade-up mt-4 font-display italic text-[18px] lg:text-[20px] text-[var(--rosa-queimado)]">Mais que indicar, conectamos cuidado de confiança.</p>

                <div className="fade-up mt-6 space-y-4 text-[14px] leading-relaxed text-[var(--text-secondary)]">
                  <p>Encontrar um cuidador de confiança para um familiar idoso em Vitória é um dos momentos mais delicados para uma família. <strong className="text-[var(--text-primary)]">Como confiar? Como saber se tem preparo, referência e humanidade?</strong></p>
                  <p>Com sua experiência como <strong className="text-[var(--text-primary)]">Bacharela em Serviço Social e criadora do Programa Recomeço</strong>, Marcy Schettino realiza seleção rigorosa, verificação de referências, capacitação e treinamento de cuidadores para indicação segura em Vitória e região.</p>
                </div>

                <div className="fade-up mt-8 grid sm:grid-cols-2 gap-3">
                  {[
                    "Verificação de antecedentes e referências pessoais e profissionais",
                    "Avaliação de perfil humano: empatia, paciência, ética, acolhimento",
                    "Capacitação técnica: higiene, alimentação, mobilidade, medicação (sem substituir equipe médica)",
                    "Treinamento prático metodologia Recomeço: vínculo, escuta, atividades lúdicas",
                    "Match cuidadoso entre perfil do idoso/família e cuidador",
                    "Acompanhamento e supervisão inicial em Vitória",
                  ].map((item, i) => (
                    <div key={i} className="flex gap-3 p-3 rounded-2xl bg-[var(--creme)] border border-[var(--border)]">
                      <div className="w-6 h-6 rounded-full bg-[#D4AF7A] flex items-center justify-center text-[12px] font-bold text-[#2D1F24] shrink-0">✓</div>
                      <span className="text-[12.5px] leading-snug text-[var(--text-primary)] font-medium">{item}</span>
                    </div>
                  ))}
                </div>

                <div className="fade-up mt-8 grid grid-cols-3 gap-3">
                  <div className="rounded-2xl bg-[var(--nude)] border border-[var(--border)] p-4"><div className="text-[20px]">🛡️</div><div className="mt-1 text-[12px] font-bold text-[var(--vinho)]">Segurança</div><div className="text-[11px] text-[var(--text-secondary)] leading-tight">Referências e antecedentes checados</div></div>
                  <div className="rounded-2xl bg-[var(--nude)] border border-[var(--border)] p-4"><div className="text-[20px]">💛</div><div className="mt-1 text-[12px] font-bold text-[var(--vinho)]">Humanidade</div><div className="text-[11px] text-[var(--text-secondary)] leading-tight">Perfil avaliado com escuta</div></div>
                  <div className="rounded-2xl bg-[#6B7A5F]/10 border border-[#6B7A5F]/20 p-4"><div className="text-[20px]">🌱</div><div className="mt-1 text-[12px] font-bold text-[#6B7A5F]">Método Recomeço</div><div className="text-[11px] text-[var(--text-secondary)] leading-tight">Treinamento prático</div></div>
                </div>

                <div className="fade-up mt-8 rounded-2xl bg-[#F9E8EC] border border-[#E9C2BB] p-4">
                  <div className="flex gap-2"><span className="text-[14px]">⚠️</span><p className="text-[12px] leading-relaxed text-[#7A3B4E]"><strong>Aviso ético:</strong> Marcy realiza indicação e capacitação. Não é agência de emprego. A contratação é direta entre família e cuidador em Vitória. O trabalho não substitui acompanhamento médico, de enfermagem ou multiprofissional.</p></div>
                </div>

                <div className="fade-up mt-6">
                  <a href="https://wa.me/5527995799138?text=Olá%20Marcy,%20vi%20no%20site%20sobre%20indicação%20de%20cuidadores%20referenciados%20em%20Vitória%20e%20gostaria%20de%20saber%20mais" target="_blank" rel="noopener" className="w-full lg:w-auto inline-flex h-[56px] px-8 rounded-full bg-[#25D366] text-white font-bold text-[14px] items-center justify-center gap-3 shadow-[0_8px_24px_rgba(37,211,102,0.3)] hover:scale-[1.01] transition">QUERO INDICAÇÃO DE CUIDADOR DE CONFIANÇA EM VITÓRIA <span>→</span></a>
                  <p className="mt-3 text-[11px] text-[var(--text-muted)]">Atendimento presencial em Vitória - Jardim da Penha, Praia do Canto, Jardim Camburi e toda Grande Vitória. Online para orientação inicial.</p>
                </div>
              </div>

              <div className="relative bg-[var(--nude)] p-6 lg:p-8 flex flex-col">
                <div className="fade-up relative rounded-[32px] overflow-hidden shadow-[var(--shadow-medium)] aspect-[4/5] bg-white">
                  <img src={fotoSobre} alt="Marcy Schettino - seleção de cuidadores em Vitória ES" className="w-full h-full object-cover" />
                  <div className="absolute top-4 left-4 px-4 py-2 rounded-full bg-white shadow-sm text-[12px] font-bold text-[var(--vinho)] flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-[#25D366] animate-pulse" />Vitória - ES • Disponível</div>
                  <div className="absolute bottom-4 left-4 right-4 rounded-[20px] bg-white/95 backdrop-blur p-4 shadow-sm">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-[var(--nude)] flex items-center justify-center text-[12px]">🌸</div>
                      <div><div className="text-[13px] font-bold text-[var(--vinho)]">Seleção com supervisão</div><div className="text-[11px] text-[var(--text-secondary)]">Método Recomeço • CRSS 09100</div></div>
                    </div>
                    <div className="mt-3 grid grid-cols-2 gap-2">
                      <div className="rounded-xl bg-[var(--nude)] p-2 text-center"><div className="text-[12px] font-bold text-[var(--vinho)]">100%</div><div className="text-[10px] text-[var(--text-muted)]">Referências checadas</div></div>
                      <div className="rounded-xl bg-[#6B7A5F]/10 p-2 text-center"><div className="text-[12px] font-bold text-[#6B7A5F]">Match</div><div className="text-[10px] text-[var(--text-muted)]">Família + Cuidador</div></div>
                    </div>
                  </div>
                </div>

                <div className="fade-up mt-6 rounded-2xl bg-white border border-[var(--border)] p-4">
                  <div className="text-[11px] font-bold tracking-wide uppercase text-[var(--rosa-queimado)] mb-2">Como funciona em Vitória</div>
                  <ol className="space-y-2 text-[12.5px] text-[var(--text-secondary)]">
                    <li className="flex gap-2"><span className="font-bold text-[var(--vinho)]">1.</span> Conversa inicial por WhatsApp</li>
                    <li className="flex gap-2"><span className="font-bold text-[var(--vinho)]">2.</span> Entendimento do perfil do idoso e família</li>
                    <li className="flex gap-2"><span className="font-bold text-[var(--vinho)]">3.</span> Indicação com referências + entrevista</li>
                    <li className="flex gap-2"><span className="font-bold text-[var(--vinho)]">4.</span> Acompanhamento inicial em Vitória</li>
                  </ol>
                </div>

                <div className="fade-up mt-4 text-center"><div className="text-[11px] text-[var(--text-muted)]">📍 Jardim da Penha • Praia do Canto • Jardim Camburi • Mata da Praia • Enseada • Grande Vitória</div></div>
              </div>
            </div>
          </div>
        </section>

        {/* IDOSOS - usando background div para não duplicar img */}
        <section id="recomeco-idosos" className="py-12 lg:py-16">
          <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-8 lg:gap-12 items-start">
            <div className="fade-up">
              <div className="grid grid-cols-2 gap-4">
                <div className="rounded-[24px] overflow-hidden aspect-[3/4] shadow-[var(--shadow-soft)] bg-[var(--nude)] relative">
                  <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${fotoIdosos})` }} />
                  <div className="absolute bottom-2 left-2 px-2 py-1 rounded-full bg-white/90 text-[10px] font-bold">Vitória - Atividade real</div>
                </div>
                <div className="space-y-4">
                  <div className="rounded-[24px] overflow-hidden aspect-square shadow-[var(--shadow-soft)] relative bg-[var(--nude)]">
                    <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${fotoGrupo})` }} />
                  </div>
                  <div className="rounded-[20px] bg-[var(--vinho)] text-white p-4">
                    <div className="text-[11px] uppercase tracking-wide text-[#E9C2BB]">Vitória ES</div>
                    <div className="font-display text-[18px] font-semibold mt-1 leading-tight">Mais do que cuidado, momentos que fazem sentido.</div>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <div className="fade-up text-[11px] tracking-[0.2em] uppercase font-bold text-[var(--rosa-queimado)]">Recomeço • Terceira Idade • Vitória</div>
              <h2 className="fade-up mt-2 font-display text-[32px] lg:text-[40px] leading-[0.95] tracking-[-0.02em] text-[var(--vinho)]">Atendimento lúdico-social para terceira idade em Vitória - ES</h2>
              <p className="fade-up mt-4 text-[14px] leading-relaxed text-[var(--text-secondary)]">O envelhecimento não é apenas sobre cuidados básicos. É sobre <strong className="text-[var(--text-primary)]">vínculo, pertencimento e momentos com significado</strong>. No Programa Recomeço, Marcy Schettino oferece atendimento presencial em Vitória com abordagem lúdico-social, resgatando histórias e autonomia.</p>

              <div className="fade-up mt-6 grid grid-cols-2 gap-3">
                {[
                  { icon: "🎵", title: "Música", desc: "Memórias afetivas, cantorias, ritmo" },
                  { icon: "📖", title: "Memórias", desc: "Histórias de vida, álbuns, linha do tempo" },
                  { icon: "🧩", title: "Jogos", desc: "Memória, cartas, dominó com sentido" },
                  { icon: "🎨", title: "Arte", desc: "Pintura, colagem, expressão livre" },
                  { icon: "💬", title: "Conversas", desc: "Escuta qualificada, sem pressa" },
                  { icon: "🏡", title: "Vínculo", desc: "Família, rotina, pertencimento" },
                ].map((a) => (
                  <div key={a.title} className="rounded-2xl bg-white border border-[var(--border)] p-4">
                    <div className="text-[18px]">{a.icon}</div>
                    <div className="mt-2 text-[13px] font-bold text-[var(--vinho)]">{a.title}</div>
                    <div className="text-[11.5px] text-[var(--text-secondary)] leading-snug">{a.desc}</div>
                  </div>
                ))}
              </div>

              <div className="fade-up mt-6 flex gap-3">
                <a href={waLink(TEXTOS_WA.idoso)} target="_blank" rel="noopener" className="h-12 px-6 rounded-full bg-[var(--vinho)] text-white text-[13px] font-semibold inline-flex items-center gap-2">Agendar em Vitória →</a>
                <a href="#cuidadores" className="h-12 px-6 rounded-full bg-white border border-[var(--border)] text-[13px] font-semibold inline-flex items-center gap-2">Ver cuidadores</a>
              </div>
            </div>
          </div>
        </section>

        {/* MULHERES */}
        <section id="recomeco-mulheres" className="py-12 lg:py-16">
          <div className="rounded-[32px] bg-[#FDF2E9] border border-[var(--border)] overflow-hidden">
            <div className="grid lg:grid-cols-[1.1fr_0.9fr] gap-0">
              <div className="p-7 lg:p-10">
                <div className="fade-up text-[11px] tracking-[0.2em] uppercase font-bold text-[var(--rosa-queimado)]">Recomeço • Mulheres em Reconstrução • Vitória</div>
                <h2 className="fade-up mt-2 font-display text-[30px] lg:text-[38px] leading-[0.95] text-[var(--vinho)]">Acolhimento após relações tóxicas, com respeito e sem julgamentos.</h2>
                <p className="fade-up mt-4 text-[14px] leading-relaxed text-[var(--text-secondary)]">Em Vitória - ES, Marcy oferece espaço de escuta e reconstrução para mulheres que viveram relações dolorosas. <strong className="text-[var(--text-primary)]">Sem diagnosticar parceiros, sem promessas irreais</strong>. Um trabalho complementar, que não substitui psicoterapia, mas soma cuidado humano, lúdico-social e encaminhamento responsável.</p>

                <div className="fade-up mt-6 space-y-3">
                  {[
                    "Escuta qualificada e acolhimento sem julgamento",
                    "Resgate de autoestima, limites e rede de apoio",
                    "Atividades lúdicas e narrativas de reconstrução",
                    "Orientação serviço-social e encaminhamentos em Vitória",
                    "Grupo de apoio e roda de conversa (presencial Vitória)",
                  ].map((t) => (
                    <div key={t} className="flex gap-3 items-start">
                      <div className="w-5 h-5 rounded-full bg-white border border-[var(--border)] flex items-center justify-center text-[10px] text-[var(--rosa-queimado)]">♥</div>
                      <span className="text-[13px] text-[var(--text-primary)]">{t}</span>
                    </div>
                  ))}
                </div>

                <div className="fade-up mt-6 rounded-2xl bg-white border border-[var(--border)] p-4">
                  <p className="text-[12px] leading-relaxed text-[var(--text-secondary)]"><strong className="text-[var(--vinho)]">Nota ética:</strong> Atendimento de apoio lúdico-social. Não realiza diagnóstico clínico, não substitui acompanhamento psicológico/psiquiátrico. Em situações de violência, orientamos busca por rede de proteção em Vitória - ES (DEAM, CRAMSV, Defensoria).</p>
                </div>

                <div className="fade-up mt-6 flex gap-3">
                  <a href={waLink(TEXTOS_WA.mulheres)} target="_blank" rel="noopener" className="h-12 px-6 rounded-full bg-[var(--vinho)] text-white text-[13px] font-semibold inline-flex items-center gap-2">Quero acolhimento em Vitória →</a>
                </div>
              </div>

              <div className="fade-up p-6 lg:p-6 grid grid-rows-2 gap-4 bg-white">
                <div className="rounded-[24px] overflow-hidden relative bg-[var(--nude)]">
                  <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${fotoMulherChorando})` }} />
                  <div className="absolute bottom-3 left-3 px-3 py-1 rounded-full bg-white text-[11px] font-bold text-[var(--vinho)]">Atendimento individual • Vitória</div>
                </div>
                <div className="rounded-[24px] overflow-hidden relative">
                  <img src={fotoRodaMulheres} alt="Roda de mulheres com Marcy facilitando em Vitória" className="w-full h-full object-cover" />
                  <div className="absolute bottom-3 left-3 px-3 py-1 rounded-full bg-[var(--vinho)] text-white text-[11px] font-bold">Roda de mulheres • Grande Vitória</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* SOBRE */}
        <section id="sobre" className="py-12 lg:py-20">
          <div className="grid lg:grid-cols-[0.95fr_1.05fr] gap-8 lg:gap-14 items-center">
            <div className="fade-up relative">
              <div className="rounded-[32px] overflow-hidden aspect-[4/5] shadow-[var(--shadow-medium)] bg-[var(--nude)] relative">
                <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${fotoSobre})` }} />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
              </div>
              <div className="absolute -bottom-6 -right-4 lg:right-0 bg-white rounded-[20px] border border-[var(--border)] shadow-[var(--shadow-soft)] p-4 max-w-[240px]">
                <div className="flex items-center gap-2"><div className="w-8 h-8 rounded-full bg-[var(--nude)] flex items-center justify-center text-[14px]">🎙️</div><div className="text-[12px] font-bold text-[var(--vinho)]">Palestrante</div></div>
                <div className="mt-2 text-[12px] leading-snug text-[var(--text-secondary)]">Temas: envelhecimento com significado, relações tóxicas, cuidado humanizado em Vitória.</div>
              </div>
              <div className="absolute -top-4 -left-4 bg-[#D4AF7A] rounded-full w-20 h-20 flex items-center justify-center shadow-[var(--shadow-soft)]"><span className="font-display font-bold text-[18px] text-[#2D1F24] leading-none text-center">CRSS<br/>09100</span></div>
            </div>

            <div>
              <div className="fade-up text-[11px] tracking-[0.2em] uppercase font-bold text-[var(--rosa-queimado)]">Sobre Marcy Schettino • Vitória ES</div>
              <h2 className="fade-up mt-2 font-display text-[32px] lg:text-[42px] leading-[0.9] text-[var(--vinho)]">Bacharela em Serviço Social, Psicanalista e criadora do Recomeço.</h2>
              <div className="fade-up mt-4 flex flex-wrap gap-2">
                {["Bacharela em Serviço Social", "Assistente Social", "Psicanalista", "Pós em Psicanálise", "Palestrante", "Vitória - ES"].map((b) => (
                  <span key={b} className="px-3 py-1 rounded-full bg-white border border-[var(--border)] text-[11px] font-medium">{b}</span>
                ))}
              </div>
              <div className="fade-up mt-6 space-y-4 text-[14px] leading-relaxed text-[var(--text-secondary)]">
                <p><strong className="text-[var(--text-primary)]">Nunca psicóloga</strong> - formação correta: Bacharela em Serviço Social, Assistente Social com registro, Psicanalista, Pós Graduada em Psicanálise e Palestrante. Atua com abordagem lúdico-social, escuta qualificada e metodologia própria Recomeço.</p>
                <p>Em Vitória - ES, seu trabalho une técnica, humanidade e presença. Seja no atendimento a idosos que precisam de vínculo, mulheres em reconstrução ou na seleção cuidadosa de cuidadores referenciados para famílias capixabas.</p>
                <p className="font-display italic text-[18px] text-[var(--vinho)]">“Mais do que cuidado, momentos que fazem sentido.”</p>
              </div>

              <div className="fade-up mt-6 grid grid-cols-2 gap-3">
                <div className="rounded-2xl bg-white border border-[var(--border)] p-4"><div className="text-[12px] font-bold text-[var(--vinho)]">Missão</div><div className="text-[12px] text-[var(--text-secondary)] leading-snug mt-1">Reconstruir caminhos com cuidado humano, lúdico e responsável em Vitória e região.</div></div>
                <div className="rounded-2xl bg-white border border-[var(--border)] p-4"><div className="text-[12px] font-bold text-[var(--vinho)]">Abordagem</div><div className="text-[12px] text-[var(--text-secondary)] leading-snug mt-1">Escuta, vínculo, atividades com significado, sem substituir equipe médica.</div></div>
              </div>

              <div className="fade-up mt-6 rounded-[20px] overflow-hidden border border-[var(--border)] h-[180px] relative bg-[var(--nude)]">
                <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${heroPalestra})` }} />
                <div className="absolute bottom-3 left-3 px-3 py-1 rounded-full bg-white text-[11px] font-bold text-[var(--vinho)]">Palestrando em Vitória - ES</div>
              </div>
            </div>
          </div>
        </section>

        {/* PALESTRAS */}
        <section id="palestras" className="py-12 lg:py-16">
          <div className="rounded-[32px] bg-[var(--vinho)] text-white overflow-hidden relative">
            <div className="absolute inset-0 opacity-20 bg-cover bg-center" style={{ backgroundImage: `url(${heroPalestra})` }} />
            <div className="relative grid lg:grid-cols-[1.1fr_0.9fr] gap-0">
              <div className="p-7 lg:p-12">
                <div className="fade-up text-[11px] tracking-[0.2em] uppercase font-bold text-[#E9C2BB]">Palestras • Vitória, Vila Velha, Serra, Grande Vitória e Online</div>
                <h2 className="fade-up mt-3 font-display text-[32px] lg:text-[44px] leading-[0.9]">Palestras que tocam, informam e transformam.</h2>
                <p className="fade-up mt-4 text-[14px] leading-relaxed text-[#E9C2BB] max-w-[520px]">Conteúdo acessível, humano e prático para empresas, igrejas, escolas, grupos de idosos e eventos em Vitória - ES. Presencial na Grande Vitória e online para todo Brasil.</p>

                <div className="fade-up mt-8 grid sm:grid-cols-2 gap-3">
                  {[
                    { t: "Envelhecimento com significado", d: "Além do cuidado básico, como criar momentos de vida" },
                    { t: "Relações tóxicas e reconstrução", d: "Limites, autoestima e rede de apoio (sem diagnóstico de terceiros)" },
                    { t: "Cuidado humanizado", d: "Para equipes, cuidadores e famílias - ética e presença" },
                    { t: "Família e cuidador em Vitória", d: "Como escolher, orientar e acompanhar com segurança" },
                  ].map((p) => (
                    <div key={p.t} className="rounded-2xl bg-white/10 border border-white/15 p-4 backdrop-blur"><div className="text-[13px] font-bold">{p.t}</div><div className="text-[12px] text-[#E9C2BB] mt-1 leading-snug">{p.d}</div></div>
                  ))}
                </div>

                <div className="fade-up mt-8 flex flex-wrap gap-3">
                  <a href={waLink(TEXTOS_WA.palestra)} target="_blank" rel="noopener" className="h-12 px-7 rounded-full bg-white text-[var(--vinho)] font-bold text-[13px] inline-flex items-center gap-2">Contratar palestra em Vitória →</a>
                  <span className="h-12 px-4 rounded-full bg-white/10 border border-white/15 inline-flex items-center text-[11px]">📍 Vitória • Vila Velha • Serra • Cariacica • Online</span>
                </div>
              </div>

              <div className="fade-up p-6 lg:p-8">
                <div className="rounded-[24px] overflow-hidden bg-white aspect-[4/5] lg:aspect-[4/3] relative">
                  <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${heroPalestra})` }} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4 rounded-2xl bg-white p-4">
                    <div className="text-[12px] font-bold text-[var(--vinho)]">Próximas agendas em Vitória</div>
                    <div className="text-[11px] text-[var(--text-secondary)] mt-1">Consulte disponibilidade para empresas, igrejas e grupos. Formato palestra + roda de conversa.</div>
                    <div className="mt-2 inline-flex px-3 py-1 rounded-full bg-[#25D366] text-white text-[11px] font-bold">WhatsApp (27) 99579-9138</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CONTATO */}
        <section id="contato" className="py-12 lg:py-20">
          <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-8 lg:gap-12">
            <div>
              <div className="fade-up text-[11px] tracking-[0.2em] uppercase font-bold text-[var(--rosa-queimado)]">Contato • Vitória ES</div>
              <h2 className="fade-up mt-2 font-display text-[34px] lg:text-[44px] leading-[0.9] text-[var(--vinho)]">Atendimento presencial em Vitória - ES e região. Online para todo Brasil.</h2>

              <div className="fade-up mt-6 rounded-[24px] bg-white border border-[var(--border)] p-6">
                <div className="flex items-center gap-3"><div className="w-10 h-10 rounded-full bg-[#25D366] flex items-center justify-center text-white font-bold">WA</div><div><div className="text-[13px] font-bold text-[var(--vinho)]">WhatsApp (27) 99579-9138</div><div className="text-[11px] text-[var(--text-secondary)]">Resposta em horário comercial • Vitória ES</div></div></div>
                <div className="mt-4 grid grid-cols-2 gap-3 text-[12px]">
                  <div className="rounded-xl bg-[var(--nude)] p-3"><div className="font-bold text-[var(--vinho)]">📧 Email</div><div className="text-[11px] text-[var(--text-secondary)] break-all">marcilenesdacosta@gmail.com</div></div>
                  <div className="rounded-xl bg-[var(--nude)] p-3"><div className="font-bold text-[var(--vinho)]">📸 Instagram</div><div className="text-[11px] text-[var(--text-secondary)]">@marcyschettino</div></div>
                  <div className="rounded-xl bg-[var(--nude)] p-3 col-span-2"><div className="font-bold text-[var(--vinho)]">🌐 Site</div><div className="text-[11px] text-[var(--text-secondary)]">www.marcyschettino.com • Vitória - ES • CRSS 09100</div></div>
                </div>

                <div className="mt-5 rounded-xl bg-[#6B7A5F]/10 border border-[#6B7A5F]/20 p-3">
                  <div className="text-[11px] font-bold text-[#6B7A5F]">📍 Mapa mental Grande Vitória</div>
                  <div className="mt-2 text-[11px] leading-relaxed text-[var(--text-secondary)]">Jardim da Penha • Praia do Canto • Jardim Camburi • Mata da Praia • Enseada • Jardim Camburi • Praia da Costa (Vila Velha) • Laranjeiras (Serra) • Atendimento presencial nesses bairros + online Brasil.</div>
                </div>

                <div className="mt-5 flex gap-2">
                  <a href={waLink(TEXTOS_WA.geral)} target="_blank" rel="noopener" className="flex-1 h-11 rounded-full bg-[#25D366] text-white font-bold text-[12px] inline-flex items-center justify-center">WhatsApp</a>
                  <a href="https://instagram.com/marcyschettino" target="_blank" rel="noopener" className="flex-1 h-11 rounded-full bg-white border border-[var(--border)] font-bold text-[12px] inline-flex items-center justify-center">Instagram</a>
                </div>

                {recordsCount !== null && <div className="mt-4 text-[11px] text-[var(--text-muted)] text-center">{recordsCount} solicitações registradas com carinho em Vitória • dados salvos localmente</div>}
              </div>
            </div>

            <div className="fade-up rounded-[28px] bg-white border border-[var(--border)] shadow-[var(--shadow-soft)] p-7 lg:p-8">
              <h3 className="font-display text-[22px] font-semibold text-[var(--vinho)]">Solicitar contato / cuidador em Vitória</h3>
              <p className="mt-2 text-[12.5px] text-[var(--text-secondary)]">Preencha e receba retorno por WhatsApp. Se preferir, clique direto no botão verde. Formulário salvo com segurança (persistência local).</p>

              <form onSubmit={submitForm} className="mt-6 space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div><label className="text-[11px] font-bold uppercase tracking-wide text-[var(--text-muted)]">Nome completo *</label><input value={formData.nome} onChange={(e) => setFormData({ ...formData, nome: e.target.value })} className="mt-1 w-full h-11 rounded-full border border-[var(--border)] px-4 text-[13px] outline-none focus:border-[var(--rosa-queimado)] bg-[var(--creme)]" placeholder="Seu nome" /></div>
                  <div><label className="text-[11px] font-bold uppercase tracking-wide text-[var(--text-muted)]">WhatsApp *</label><input value={formData.whatsapp} onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })} className="mt-1 w-full h-11 rounded-full border border-[var(--border)] px-4 text-[13px] outline-none focus:border-[var(--rosa-queimado)] bg-[var(--creme)]" placeholder="(27) 9xxxx-xxxx" /></div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div><label className="text-[11px] font-bold uppercase tracking-wide text-[var(--text-muted)]">Bairro em Vitória</label><input value={formData.bairro} onChange={(e) => setFormData({ ...formData, bairro: e.target.value })} className="mt-1 w-full h-11 rounded-full border border-[var(--border)] px-4 text-[13px] outline-none focus:border-[var(--rosa-queimado)] bg-[var(--creme)]" placeholder="Ex: Jardim da Penha" /></div>
                  <div><label className="text-[11px] font-bold uppercase tracking-wide text-[var(--text-muted)]">Interesse</label><select value={formData.tipo} onChange={(e) => setFormData({ ...formData, tipo: e.target.value })} className="mt-1 w-full h-11 rounded-full border border-[var(--border)] px-4 text-[13px] outline-none bg-[var(--creme)]"><option>Cuidadores Referenciados - Vitória</option><option>Recomeço Terceira Idade - Vitória</option><option>Recomeço Mulheres - Vitória</option><option>Palestra em Vitória / GV</option><option>Outro - Online Brasil</option></select></div>
                </div>

                <div><label className="text-[11px] font-bold uppercase tracking-wide text-[var(--text-muted)]">Mensagem</label><textarea value={formData.mensagem} onChange={(e) => setFormData({ ...formData, mensagem: e.target.value })} rows={4} className="mt-1 w-full rounded-[20px] border border-[var(--border)] p-4 text-[13px] outline-none focus:border-[var(--rosa-queimado)] bg-[var(--creme)] resize-none" placeholder="Conte brevemente sua necessidade em Vitória..." /></div>

                <button disabled={busy} className="w-full h-[52px] rounded-full bg-[var(--vinho)] text-white font-bold text-[14px] disabled:opacity-60 hover:bg-[#5E2E3E] transition">{busy ? "Enviando..." : "Enviar solicitação para Vitória"}</button>

                {formStatus && <div className="rounded-2xl bg-[var(--nude)] border border-[var(--border)] p-3 text-[12.5px] text-[var(--vinho)] leading-relaxed">{formStatus}</div>}

                <div className="flex gap-2"><a href={waLink(TEXTOS_WA.cuidadores)} target="_blank" rel="noopener" className="flex-1 h-11 rounded-full bg-[#25D366] text-white font-bold text-[12px] inline-flex items-center justify-center">WhatsApp cuidadores</a><a href={waLink(TEXTOS_WA.geral)} target="_blank" rel="noopener" className="flex-1 h-11 rounded-full bg-white border border-[var(--border)] font-bold text-[12px] inline-flex items-center justify-center">WhatsApp geral</a></div>

                <p className="text-[10.5px] leading-relaxed text-[var(--text-muted)] text-center">Ao enviar, você concorda com contato via WhatsApp. Dados armazenados apenas para organização de atendimentos em Vitória - ES. Não é agência. Contratação direta família-cuidador.</p>
              </form>
            </div>
          </div>
        </section>
      </main>

      <footer className="mt-8 border-t border-[var(--border)] bg-white">
        <div className="mx-auto max-w-[1280px] px-6 lg:px-8 py-10 lg:py-14">
          <div className="grid lg:grid-cols-[1.2fr_0.8fr_0.8fr] gap-8">
            <div>
              <div className="flex items-center gap-3"><div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#D4AF7A] to-[#C17C74] flex items-center justify-center"><span className="text-white text-[12px]">♥</span></div><span className="font-display font-bold text-[18px] text-[var(--vinho)]">Marcy Schettino</span></div>
              <p className="mt-3 text-[13px] leading-relaxed text-[var(--text-secondary)] max-w-[380px]">Programa Recomeço com 3 eixos: Terceira Idade (lúdico-social), Mulheres em Reconstrução e Cuidadores Referenciados em Vitória - ES. Bacharela em Serviço Social | CRSS 09100 | Psicanalista | Palestrante.</p>
              <div className="mt-4 flex flex-wrap gap-2"><span className="px-3 py-1 rounded-full bg-[var(--nude)] border border-[var(--border)] text-[11px]">VITÓRIA ES PRESENCIAL</span><span className="px-3 py-1 rounded-full bg-[#6B7A5F] text-white text-[11px]">CUIDADORES REFERENCIADOS NOVO</span></div>
            </div>
            <div><div className="text-[11px] font-bold tracking-[0.15em] uppercase text-[var(--text-muted)]">Programa Recomeço • 3 eixos</div><ul className="mt-3 space-y-2 text-[13px] text-[var(--text-secondary)]"><li>• Terceira Idade - Atividades com significado - Vitória ES</li><li>• Mulheres em Reconstrução - Acolhimento pós relação tóxica</li><li>• Cuidadores Referenciados - Indicação segura em Vitória</li><li>• Palestras - Grande Vitória e Online</li></ul></div>
            <div><div className="text-[11px] font-bold tracking-[0.15em] uppercase text-[var(--text-muted)]">Contato oficial Vitória</div><div className="mt-3 space-y-2 text-[13px] text-[var(--text-secondary)]"><div>WhatsApp: (27) 99579-9138</div><div>Email: marcilenesdacosta@gmail.com</div><div>Instagram: @marcyschettino</div><div>Site: www.marcyschettino.com</div><div>Atendimento: Vitória, Vila Velha, Serra, Grande Vitória + Online Brasil</div></div><div className="mt-4 flex gap-2"><a href={waLink(TEXTOS_WA.geral)} target="_blank" rel="noopener" className="h-9 px-4 rounded-full bg-[#25D366] text-white text-[12px] font-bold inline-flex items-center">WhatsApp</a><a href="https://instagram.com/marcyschettino" target="_blank" rel="noopener" className="h-9 px-4 rounded-full border border-[var(--border)] text-[12px] font-bold inline-flex items-center">Instagram</a></div></div>
          </div>

          <div className="mt-10 rounded-2xl bg-[var(--creme)] border border-[var(--border)] p-4"><p className="text-[11px] leading-relaxed text-[var(--text-secondary)]"><strong>Aviso ético geral:</strong> Marcy Schettino é Bacharela em Serviço Social, Assistente Social (CRSS 09100), Psicanalista e Palestrante. Não é psicóloga. O Programa Recomeço é apoio lúdico-social, complementar e não substitui acompanhamento médico, psicológico, de enfermagem ou multiprofissional. Para Cuidadores Referenciados em Vitória, realiza seleção, capacitação e indicação - contratação direta entre família e cuidador. Em situações de risco ou violência, procure rede de proteção local em Vitória - ES.</p></div>

          <div className="mt-6 flex flex-col lg:flex-row justify-between gap-2 text-[11px] text-[var(--text-muted)]"><span>© 2026 Marcy Schettino - Vitória ES - CRSS 09100 • Programa Recomeço • Todos os direitos reservados</span><span>Desenvolvido premium • SEO Vitória - ES • Grande Vitória • Espírito Santo</span></div>
        </div>
      </footer>

      <a href={waLink(TEXTOS_WA.geral)} target="_blank" rel="noopener" className="fixed bottom-5 right-5 z-50 w-14 h-14 rounded-full bg-[#25D366] shadow-[0_8px_24px_rgba(37,211,102,0.4)] flex items-center justify-center text-white text-[22px] hover:scale-105 transition" aria-label="WhatsApp Marcy Vitória">✦</a>
    </div>
  );
}
